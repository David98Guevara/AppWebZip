<style type="text/css">
	th{
		text-align: right;
	}
	h2{
		text-align: center;
	}
</style>

<head>
	<meta charset="utf-8"> <!--Idioma Español--->
	<link rel="icon" type="img/png" href="https://www.shutterstock.com/image-vector/local-fruit-vegetables-store-building-260nw-298262603.jpg">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Login</title>
</head>
<body>
	<h2> LOGIN </h2>
	<form method="post" action="validar.php">
		<tr><th>usuario</th><td><input type="text" name="usuario"></td></tr>
		<tr><th>contraseña</th><td><input type="password" name="password"></td></tr>
	<tr><td colspan = "2" align="center"><input type="checkbox" name="remember" value="1">Remember Me</td><tr>
	<tr><td colspan = "2" align="right"><input type="submit" value="Login" name="login"></td><tr> 
	
	<!-- <input type="text" name="usuario"></td>
		</tr>
	</form>
		
		<h2>Usuario</h2>
		<div class="contenedor">
		<div class="input-contenedor">
			<input type="text" placeholder="Nombre">
		</div>

		<h2>Contraseña</h2>
		<div class="contenedor">
		<div class="input-contenedor">
			<input type="password" placeholder="Contraseña">
	 -->


</body>
</html>