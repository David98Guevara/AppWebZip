<?php
	session_start();
	session_destroy();
	echo "Saliste con exito clic aquí para <a href='login.php'> entra de nuevo </a>"
?>